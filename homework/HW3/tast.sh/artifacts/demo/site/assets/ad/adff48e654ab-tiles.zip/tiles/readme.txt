Sample tiles for ForumKeep demo.

Sample theme package.
